package com.omnicraft;

import net.minecraft.resources.Identifier;

import net.fabricmc.api.ModInitializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common entrypoint: runs on the physical client and on the dedicated server.
 * Everything client-only lives in {@code com.omnicraft.client}.
 */
public final class OmniCraft implements ModInitializer {
	public static final String MOD_ID = "omnicraft";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/**
	 * Creates an identifier in the mod namespace, e.g. {@code omnicraft:chair}.
	 */
	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		LOGGER.info("OmniCraft: common side initialized");
	}
}
