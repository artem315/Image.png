package com.omnicraft.client;

import net.fabricmc.api.ClientModInitializer;

import com.omnicraft.OmniCraft;

/**
 * Client-only entrypoint: renderers, screens, key mappings and client-side networking.
 */
public final class OmniCraftClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		OmniCraft.LOGGER.info("OmniCraft: client side initialized");
	}
}
